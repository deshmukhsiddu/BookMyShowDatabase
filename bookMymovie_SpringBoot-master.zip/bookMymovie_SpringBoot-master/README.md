# bookMymovie_SpringBoot
In this project movie ticket is booked using bookMymovie system. We enter into Web page if its new user then register by clicking on Sign in button or if existing user  logging with User Name and Password. Then we select the Movie and later in which Theatre movie is running. Later choose Show Timings and enter no of tickets you want . Finally it displays the details of the booking and send the email at respective users email id.

# Git Url
  ```git
  git clone https://github.com/ntanaji/bookMymovie_SpringBoot.git
  ```

# Software Requirements
- install mysql-5.5.24-winx64 in your local machine
- find the mysql-5.5.24-winx64 app in src/main/resources/dbapps folder
- install and run dbeaver app to connect and use mysql db
- find the dbeaver app in src/main/resources/dbapps folder
- to connect the mysql db from dbeaver we need mysql-connectorj.jar file
- find the mysql-connectorj.jar app in src/main/resources/dbapps folder
- Restore db dump to mysql from src/main/resources/moviebooking.sql
- we need java 8 version with sts-4.
- Run the application as spring boot application

# Swagger documents
```git
 http://localhost:8080/swagger-ui.html
 ```
