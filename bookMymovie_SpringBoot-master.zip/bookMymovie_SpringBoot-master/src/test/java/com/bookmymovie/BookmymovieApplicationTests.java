package com.bookmymovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmymovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
